# Duck Code

This directory contains source and
object code files of DM2019S machine
code.  The source code is in an assembly
code format, .asm (with symbolic labels) 
or .dasm (with all labels "resolved" to 
numbers).  The object code is
in standard Duck Machine Object Code
format, .obj. 
