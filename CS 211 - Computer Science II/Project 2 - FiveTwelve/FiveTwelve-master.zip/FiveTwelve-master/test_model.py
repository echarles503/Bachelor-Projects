"""
Tests for model.py.

Note that the unittest module predates PEP-8 guidelines, which
is why we have a bunch of names that don't comply with the
standard.
"""
import model
from model import Vec
import unittest
import sys



if __name__ == "__main__":
    unittest.main()
