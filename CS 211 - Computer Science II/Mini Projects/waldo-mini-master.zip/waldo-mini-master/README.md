# waldo-mini
"For all" and "There exists",  in rows and columns of a matrix

Mini-project for CIS 211, University of Oregon, Spring 2019
