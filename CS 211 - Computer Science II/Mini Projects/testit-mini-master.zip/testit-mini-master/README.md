# testit-mini
Build a test suite that reveals two bugs in the function 
